You are allowed to reupload this Model, if you note my Name and changed something.

Tip: You can deactivate Smooth Shading for the Model :D.